package tesi.bean;

import java.util.Map;
import java.util.TreeMap;


/**
 *   SEMPLIFICAZIONI:
 *   -la domanda mensile � considerata costante
 *   -il lead time � pari ad 1 gg per ogni prodotto
 *   -il magazzino iniziale � pari a 1000 per tutti i componenti
	
 * @author Nancy
 *
 */
public class Prodotto implements Comparable<Prodotto>{
	
	private String prodottoID;
	private String descrizione;
	private float domandaMensile; 
	private int leadTime;
	private float lotSize;
	private float valore;
	private float magazzino;
	private Map<Prodotto,Float> parents; 	
	
	
	public Prodotto(String prodottoID, String descrizione,
			float domandaMensile, int leadTime, float lotSize, float valore) {
		super();
		this.prodottoID = prodottoID;
		this.descrizione = descrizione;
		this.domandaMensile = domandaMensile;
		this.leadTime = leadTime;
		this.lotSize = lotSize;
		this.valore = valore;
		this.magazzino=40;
		
		this.parents= new TreeMap<Prodotto, Float>(); //creo una istanza vuota!
	}
	
	/**
	 * Aggiunta di un componente al prodotto
	 * @param p componente da aggiungere
	 * @param q quantit� di p necessaria per il prodotto
	 */
	
	public void AggiungiParents(Prodotto p,float q){
		parents.put(p, q);
	}
	
	
	/**
	 * Controllo che il prodotto sia finito
	 * @return true se � un prodotto finito
	 */

	
	public boolean isProdottoFinito(){
		if(prodottoID.startsWith("PS"))
			return true;
		return false;
	}
	
	
	
	public String getProdottoID() {
		return prodottoID;
	}

	public void setProdottoID(String prodottoID) {
		this.prodottoID = prodottoID;
	}

	public String getDescrizione() {
		return descrizione;
	}
	
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	
	public float getDomandaMensile() {
		return domandaMensile;
	}
	
	public void setDomandaMensile(float domandaMensile) {
		this.domandaMensile = domandaMensile;
	}
	
	public int getLeadTime() {
		return leadTime;
	}
	
	public void setLeadTime(int leadTime) {
		this.leadTime = leadTime;
	}
	
	public float getLotSize() {
		return lotSize;
	}
	
	public void setLotSize(float lotSize) {
		this.lotSize = lotSize;
	}
	
	public float getValore() {
		return valore;
	}
	
	public void setValore(float valore) {
		this.valore = valore;
	}

	
	public float getMagazzino() {
		return magazzino;
	}


	public void setMagazzinoIniziale(float magazzinoIniziale) {
		this.magazzino = magazzinoIniziale;
	}

	
	public Map<Prodotto,Float> getParents() {
		return parents;
	}


	public void setParents(Map<Prodotto,Float> parents) {
		this.parents = parents;
	}
	
	
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((descrizione == null) ? 0 : descrizione.hashCode());
		result = prime * result + Float.floatToIntBits(domandaMensile);
		result = prime * result + leadTime;
		result = prime * result + Float.floatToIntBits(lotSize);
		result = prime * result
				+ ((prodottoID == null) ? 0 : prodottoID.hashCode());
		result = prime * result + Float.floatToIntBits(valore);
		return result;
	}


	@Override
	public String toString() {
		return "ProdottoID=" + prodottoID + "\nDescrizione="
				+ descrizione + "\ndomandaMensile=" + domandaMensile
				+ "\nleadTime=" + leadTime + "\nlotSize=" + lotSize
				+ "\nvalore=" + valore + "\nmagazzino=" + magazzino;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Prodotto other = (Prodotto) obj;
		if (descrizione == null) {
			if (other.descrizione != null)
				return false;
		} else if (!descrizione.equals(other.descrizione))
			return false;
		if (Float.floatToIntBits(domandaMensile) != Float
				.floatToIntBits(other.domandaMensile))
			return false;
		if (leadTime != other.leadTime)
			return false;
		if (Float.floatToIntBits(lotSize) != Float
				.floatToIntBits(other.lotSize))
			return false;
		if (prodottoID == null) {
			if (other.prodottoID != null)
				return false;
		} else if (!prodottoID.equals(other.prodottoID))
			return false;
		if (Float.floatToIntBits(valore) != Float.floatToIntBits(other.valore))
			return false;
		return true;
	}


	@Override
	public int compareTo(Prodotto o) {
		if(this.getProdottoID().equals(o.getProdottoID()))
		return 0;
		return -1;
	}


	
	
	
	
	
	

	
  
}
