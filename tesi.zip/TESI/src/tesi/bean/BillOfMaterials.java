package tesi.bean;

import java.util.ArrayList;
import java.util.List;

import org.jgrapht.DirectedGraph;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.DirectedMultigraph;
/**
 * BillOfMaterials mi permette di creare la distinta base per un materiale
 * NOTA:uso di ricorsione nel metodo cercaComponenti
 * @author Nancy
 *
 */


public class BillOfMaterials {

	
	private DirectedGraph<Prodotto, DefaultEdge> BOM;
	
	/**
	 * Creazione della distinta base
	 * @param p prodotto finito
	 * @param listaComponenti relazioni di dipendenza tra i componenti
	 */

	public void creaBom(Prodotto p,List<Prodotto> listaComponenti){
		creaBom(p);
		cercaComponenti(p, listaComponenti);
	}
	
	
	 
	private void creaBom(Prodotto p){
		BOM= new DirectedMultigraph<>(DefaultEdge.class);
		BOM.addVertex(p);		
	}
	

	/**
	 * Algoritmo ricorsivo
	 * Aggiunta delle relazioni esistenti tra i diversi materiali
	 * @param p materiale di partenza
	 * @param listaComponenti 
	 * @return lista dei componenti del materiale p di partenza
	 */
	private List<Prodotto> cercaComponenti(Prodotto p,List<Prodotto> listaComponenti){
		List<Prodotto> lista = new ArrayList<>();
		
		for(Prodotto c : listaComponenti){
			for(Prodotto parent : c.getParents().keySet())
			if(parent!=null && parent.getProdottoID().equals(p.getProdottoID()))
				lista.add(c);
			}
	
		for(Prodotto c:lista)
			aggiungiComponente(p, c);
		
		
		for(Prodotto c:lista)
			cercaComponenti(c, listaComponenti);
		
	return lista;
	}
	
	
	/**
	 *Costruzione dell'arco di collegamento con eventuale aggiunta dei due prodotti  
	 * @param padre 
	 * @param figlio
	 */
     private void aggiungiComponente(Prodotto padre,Prodotto figlio){
		if(!BOM.containsVertex(padre))
		                 BOM.addVertex(padre);
		
		if(!BOM.containsVertex(figlio))
		                  BOM.addVertex(figlio);
		
		BOM.addEdge(padre, figlio);
	}
     
     

	public DirectedGraph<Prodotto, DefaultEdge> getBOM() {
		return BOM;
	}
	

	public void setBOM(DirectedGraph<Prodotto, DefaultEdge> bOM) {
		BOM = bOM;
	}
	
	
	public float getQuantita(Prodotto padre,Prodotto figlio){
		DefaultEdge e = BOM.getEdge(padre, figlio);
		if(e!=null)
		return figlio.getParents().get(padre);
		return 0;
	}

	
	
	
	
	
	
	
}
