package tesi;



import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import tesi.bean.BillOfMaterials;
import tesi.bean.Prodotto;
import tesi.dao.ProdottoDAO;

public class Model {
	
	private Map <String,Prodotto> listaProdotti;
	private List<Prodotto> listaComponenti;
	 
	
	
     public Model() {
		
    	  ProdottoDAO dao = new ProdottoDAO();
    	  Map <String,Prodotto> listaProdotti = dao.getAllProdotto();
    	  List<Prodotto> listaComponenti = dao.getAllComponente();
		  setListaProdotti(listaProdotti);
		  setListaComponenti(listaComponenti);

	}
	
	
	
	public Map<String, Prodotto> getListaProdotti() {
		return listaProdotti;
	}
	public void setListaProdotti(Map<String, Prodotto> listaProdotti) {
		this.listaProdotti = listaProdotti;
	}
	public List<Prodotto> getListaComponenti() {
		return listaComponenti;
	}
	public void setListaComponenti(List<Prodotto> listaComponenti) {
		this.listaComponenti = listaComponenti;
	}
	
	
	public Prodotto cercaInfo(String codiceProdotto){
		return listaProdotti.get(codiceProdotto);
		}
	
	public String generaMRP(String codice){
		Prodotto p = listaProdotti.get(codice);
		return generaMRP(p, listaComponenti);
	}
	
    private String generaMRP(Prodotto p,List<Prodotto> listaComponenti){
		AlgoritmoMRP algoritmo= new AlgoritmoMRP();
		BillOfMaterials bom = new BillOfMaterials();
		bom.creaBom(p,listaComponenti);
		algoritmo.generaMRP(p, bom);
		 Map<String, float[][]> table = algoritmo.getResult();
		 StringBuffer result= new StringBuffer();
		 
		 for(String s : table.keySet()){
			float tb[][]=table.get(s);
				
		result.append(s+"\n");
			
		for(int i=0; i<algoritmo.getSizeRows(); i++) {
			for(int j=0; j<algoritmo.getSizeColumns(); j++) 
				result.append(tb[i][j]+"\t");
				result.append("\n");
				}
			result.append("\n");	
			}
		 
		 for(String s : algoritmo.getErrori())
			 result.append(s+"\n");
		 
		 
		 
		 return result.toString();
		     }
		 
		
	
	
	public boolean inserisciNuovoProdotto(String prodottoID, String descrizione,
			float domandaMensile, int leadTime, float lotSize, float valore){
		if(listaProdotti.get(prodottoID)!=null)
			return false;
	
		Prodotto n = new Prodotto(prodottoID, descrizione, domandaMensile, leadTime, lotSize, valore);
		listaProdotti.put(prodottoID, n);
		return true;
		
	}
	
	
	public boolean aggiungiComponente(String parent,String child,float quantita){
		Prodotto padre = listaProdotti.get(parent);
        Prodotto figlio = listaProdotti.get(child);
        if(figlio!=null && padre!=null){
               figlio.AggiungiParents(padre, quantita);
        	   listaComponenti.add(figlio) ;
        	   return true;
        	   }
        return false;
            }
        
		
	
	
	public List<String> getListaProdottiFiniti(){
		List<String> result= new ArrayList<>();
		
		List<Prodotto> all = new ArrayList<>();
		all.addAll(listaComponenti);
		for(Prodotto p:listaProdotti.values())   
			if(!listaComponenti.contains(p))
		         all.add(p);
		
		for(Prodotto p:all)
			if(p.isProdottoFinito())
				result.add(p.getProdottoID());
		return result;
	}
	
	
	
	

}
