package tesi.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;


import tesi.bean.Prodotto;
import tesi.db.DBConnect;


public class ProdottoDAO {
	
	/**
	 * estrazione dei dati dal database
	 */
	
	
	
	
	/**
	 * Estrazione di tutti i prodotti:finiti e componenti
	 * @return lista di tutti i prodotti
	 */
	public Map<String,Prodotto> getAllProdotto() {

		final String sql = "SELECT * FROM prodotto ORDER BY RAND() LIMIT 0, 10000";

		Map<String,Prodotto> result = new TreeMap<>();

		try {
			Connection conn = DBConnect.getInstance().getConnection();
		
			PreparedStatement st = conn.prepareStatement(sql);
			
			ResultSet rs = st.executeQuery() ;
			
			while(rs.next()) {
				String k = rs.getString("ProdottoID");
				Prodotto p = new Prodotto(k ,rs.getString("descrizione"),rs.getFloat("domandaMensile"),
						rs.getInt("leadTime"),rs.getFloat("lotSize"),rs.getFloat("valore"));

				
				result.put(k,p) ;
			}
			
			rs.close() ;
			st.close() ;
			conn.close() ;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return result;
	}
	
	
	
	/**
	 * estrazioni delle relazioni tra i diversi prodotti
	 * Una relazione � costituita da un prodotto padre,da un prodotto figlio e dalla quantita
	 * di prodotto figlio necessaria per un'unit� di prodotto padre
	 * @return lista delle relazioni
	 */
	public List<Prodotto> getAllComponente(){

		final String sql = "SELECT * FROM bom ORDER BY RAND() LIMIT 0, 10000";

		List<Prodotto> result = new ArrayList<Prodotto>();
		
		try {
			Connection conn = DBConnect.getInstance().getConnection();

			PreparedStatement st = conn.prepareStatement(sql);
			
			ResultSet rs = st.executeQuery() ;
			
			while(rs.next()) {
				String parentID = rs.getString("ParentID");
				String childID = rs.getString("ChildID");
				Float quantita = rs.getFloat("Quantity");
				
		        Prodotto parent = getAllProdotto().get(parentID);
		        Prodotto child = getAllProdotto().get(childID);
		       
		        
		        if(child!=null && parent!=null){
		        	if(result.contains(child)){
		        for(Prodotto p : result)
		        	if(p.equals(child))
		        		p.AggiungiParents(parent, quantita);
		        }
		        
		        else{  
		               child.AggiungiParents(parent, quantita);
		        	   result.add(child) ; 
		            }
		        }
			}
				
		
			
			rs.close() ;
			st.close() ;
			conn.close() ;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return result;
	}

}


