package tesi;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.jgrapht.Graphs;

import tesi.bean.BillOfMaterials;
import tesi.bean.Prodotto;


public class AlgoritmoMRP {

		private int sizeRows ;
		private int sizeColumns ;
		private float[][] table ;
		private Map<String, float[][]> result;
		private List<String> errori;
		
		
		/**
		 * Inizializzazione delle tabelle che conterranno il risultato dell'algoritmo
		 */
		
		public AlgoritmoMRP(){
			this.sizeRows = 5 ;
			this.sizeColumns=6;
			this.table = new float[sizeRows][sizeColumns] ;
			this.errori=new ArrayList<>();
			
			for(int i=0; i<sizeRows; i++)  
				for(int t=0; t<sizeColumns; t++)
					table[i][t] = 0 ;
			this.result=new TreeMap<String, float[][]>();
		
		}
		
     
		/**
		 *  t indica il tempo
		 *  i indica le righe
		 *  Legenda {
		 *              i=0 gross requirements G(t)
		 *              i=1 project on hand POH(t)
		 *              i=2 net requirements 
		 *              i=3 Planner order receipts POR(t)=LotSize
		 *              i=4 Planned order releases PRR(t)
		 *           } 
		 *                             
		 *    ALgoritmo:
		 *   1. G(t)=DomandaMensile ,richieste o domanda del materiale
		 *   2. POH(t)=POH(t-1)-G(t)
		 *   3. if POH(t)>0{ 
		 *        NR(t)=0
		 *        POR(t)=0
		 *        PRR(t)=0; inizializzo cmq i valori a 0
		 *        }
		 *      else {
		 *         POR(t)=LotSize*parteintera(Lotsize/-poh)
		 *         PRR(t-LeadTime)=POR(t)
		 *         NR(t)=-POH(t)
		 *        
		 *    }                                                            
		 * @param p prodotto
		 * @param bom distinta base del prodotto
		 */
	
		
		public void generaMRP(Prodotto p,BillOfMaterials bom){
			float domandaIndipendente[]= new float[sizeColumns];
			for(int i =0;i<sizeColumns;i++)  
				domandaIndipendente[i]=p.getDomandaMensile();
			generaMRP(p, domandaIndipendente,bom);
		}
		
		/**
		 * Calcolo delle richieste del Prodotto Finito
		 * @param p
		 * @param domandaIndipendente
		 * @param bom
		 */
		
		private void generaMRP(Prodotto p,float domandaIndipendente[],BillOfMaterials bom){
			
			for(int t=0;t<sizeColumns;t++){
				table[0][t]= domandaIndipendente[t]; 
			}			
		
			float POH =p.getMagazzino();
			float LotSize = p.getLotSize();
			int LeadTime=p.getLeadTime();
						
			for(int t=0;t<sizeColumns;t++){
				
				table[1][t]= POH-table[0][t]; 
					if(table[1][t]>=0){
						table[2][t]= 0; 
						table[3][t]= 0; 
						table[4][t]= 0;
					 }
					else{
						table[2][t]=-table[1][t]; 
						if(table[2][t]>LotSize)
						   table[3][t]=  (float) (LotSize*Math.ceil(((float)table[2][t]/(float)LotSize))); //POR
					    else
						   table[3][t]=LotSize;
						
					    if(t-LeadTime<=0){ 
					    	String s = "Pianificazione impossibile per "+p.getDescrizione()+" al tempo "+t;
					    	errori.add(s);
							//System.err.println("Pianificazione impossibile!");
						}
					    else
						   table[4][t-LeadTime]=table[3][t]; 
						
					 table[1][t]=table[3][t]+table[1][t];
					}
					POH=table[1][t];
				}
			this.result.put(p.getProdottoID(), table);
		
			
			//MI PREPARO PER ESPLODERE L'MRP
			float domandaDipendente[]= new float[sizeColumns]; 
			for(int t=0;t<sizeColumns;t++)                     
				domandaDipendente[t]=table[4][t]; 
			List<Prodotto> Adiacenti = Graphs.successorListOf(bom.getBOM(), p);
			if(RichiestePresenti(domandaDipendente)&& !Adiacenti.isEmpty())
			for(Prodotto c : Adiacenti){
				esplodiMRP(c, domandaDipendente,bom,p);
			}

		}
		

	/**
	 * Esplosione dell'MRP:calcolo i fabbisogni dei componenti a partire dalla domanda dipendente
	 * @param p
	 * @param richieste
	 * @param bom
	 * @param parent
	 */
		
		private void esplodiMRP(Prodotto p,float richieste[],BillOfMaterials bom,Prodotto parent){
			
			for(int t=0;t<sizeColumns;t++){
				
				Float x = p.getParents().get(parent);
				if(x!=null)
				table[0][t]= richieste[t]*x; 
				else {
					x=(float) 1;
				table[0][t]= richieste[t]*x; 
				}
					
			}
			float POH =p.getMagazzino();
			float LotSize = p.getLotSize();
			int LeadTime=p.getLeadTime();
						
			for(int t=0;t<sizeColumns;t++){
				table[1][t]= POH-table[0][t]; 
					if(table[1][t]>=0){
						table[2][t]= 0; 
						table[3][t]= 0; 
						table[4][t]= 0;  }
					else{
						table[2][t]=-table[1][t]; 
						
				         if(table[2][t]>LotSize)
						     table[3][t]=  (float) (LotSize*Math.ceil(((float)table[2][t]/(float)LotSize))); //POR
					     else
						     table[3][t]=LotSize;
						
					      if(t-LeadTime<=0){ 
					    	    String s = "Pianificazione impossibile per "+p.getDescrizione()+" al tempo "+t;
						    	errori.add(s);
						    }
					      else
						     table[4][t-LeadTime]=table[3][t]; 
						
					table[1][t]=table[3][t]+table[1][t];
					}
					
					POH=table[1][t]; 
					
				}
			this.result.put(p.getProdottoID(), table);
		
			
			float domandaDipendente[]= new float[sizeColumns]; 
			for(int t=0;t<sizeColumns;t++)                   
				domandaDipendente[t]=table[4][t]; 
			List<Prodotto> Adiacenti = Graphs.successorListOf(bom.getBOM(), p);
			if(RichiestePresenti(domandaDipendente)&& !Adiacenti.isEmpty())
			for(Prodotto c : Adiacenti){
				esplodiMRP(c, domandaDipendente,bom,p);
			}
			
			
		}
		

		/**
		 * Controllo che che abbia senso esplodere ancora l'MRP
		 * ci sono domande da esplodere?altrimenti mi fermo!
		 * @param richieste
		 * @return true se devo procedere nella ricorsione
		 */
	       private boolean RichiestePresenti(float richieste[]){
			int n =0;
			for(int i =0;i<richieste.length;i++){
				if(richieste[i]==0)
					n++;
			}
			if(n==richieste.length)
			    return false;
			return true;
			
		}
	       

	       /**
	        * Restituisce le tabelle MRP risultanti dall'algoritmo
	        * @return una mappa la cui chiave � il codice del prodotto associato alla tabella
	        */
			public Map<String, float[][]> getResult() {
				return result;
			}

			public int getSizeRows() {
				return sizeRows;
			}
			
			public void setSizeRows(int sizeRows) {
				this.sizeRows = sizeRows;
			}


			public int getSizeColumns() {
				return sizeColumns;
			}

			public void setSizeColumns(int sizeColumns) {
				this.sizeColumns = sizeColumns;
				}
			
			
			public List<String> getErrori() {
				return errori;
			}


			public void setErrori(List<String> errori) {
				this.errori = errori;
			}

	
		
		}


