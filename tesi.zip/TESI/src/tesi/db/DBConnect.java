package tesi.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 * * DBConnect realizzata come "singleton"
 */

public class DBConnect {

	static private final String jdbcUrl = "jdbc:mysql://localhost/prodottidb?user=root&password=miriam44";
	static private DBConnect instance = null ;
	
	private DBConnect () {
		instance = this ;
	}
	
	public static DBConnect getInstance() {
		if(instance == null)
			return new DBConnect() ;
		else {
	       return instance ;
		}
	}
	
	public Connection getConnection() {
		try {
			Connection conn = DriverManager.getConnection(jdbcUrl) ;
			return conn ;
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("Cannot get connection "+jdbcUrl, e) ;
		}	
	}

}
