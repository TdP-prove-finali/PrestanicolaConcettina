package tesi.gui;



import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import tesi.Model;
import tesi.bean.Prodotto;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;


public class ControllerGui {
	
	private Model model;
	
	@FXML
    private ResourceBundle resources;

    @FXML
    private URL location;
    
    @FXML
    private TextField ChildTxt;

    @FXML
    private BorderPane Controller;

    @FXML
    private TextField DescrizioneText;

    @FXML
    private TextField DomandaTxt;

    @FXML
    private TextField LeadTimeText;
    
    @FXML
    private TextField LotsizeText;

    @FXML
    private TextField ParentText;
    
    @FXML
    private TextField QuantitaText;

    @FXML
    private TextArea Result;

    @FXML
    private TextField ValoreTxt;
    
    @FXML
    private Button aggiungiButton;
    
    @FXML
    private Button cercaButton;

    @FXML
    private TextField codiceTetx;

    @FXML
    private Button generaMRPButton;

    @FXML
    private Button inserisciButton;

    @FXML
    private ComboBox<String> listaProdotti;

    @FXML
    private ComboBox<String> listaProdottiFiniti;


    @FXML
    void doAggiungiComponenti(ActionEvent event) {
    	Result.clear();
    	String parent = ParentText.getText();
    	String child = ChildTxt.getText();
    	float quantita;
    	
    	parent = ParentText.getText();
    	child = ChildTxt.getText();
    	
    	if(parent.length()==0 || child.length()==0){
    		Result.setText("Inserire codici prodotto");
    		return;
    	}
    	
    	
    	if(QuantitaText.getText().length()==0){
    	    Result.setText("Inserire una quantit�");
    	    return;
    	}
    	
    	
    	try{
      		quantita= Float.parseFloat(QuantitaText.getText());
		}
    	catch(NumberFormatException e){
    		Result.appendText("Formato numerico errato");
    		return;
    	}
    	
    	if(model.aggiungiComponente(parent, child, quantita)){
    	     Result.appendText("Componente aggiunto");
    	     ChildTxt.clear();
    	     ParentText.clear();
    	     QuantitaText.clear();
    	     
    	}
    	else
    		Result.appendText("Codici non validi");
    	
    }

    @FXML
    void doCercaProdotto(ActionEvent event) {
    	Result.clear();
    	String cerca = listaProdotti.getValue();
    	 Prodotto cercato =null;
    	
    	 if(cerca!=null)
    	     cercato = model.cercaInfo(cerca);
    	
    	if(cercato!=null)
    	   Result.setText("Informazioni cercate:\n"+cercato.toString());
    	else
    		Result.setText("Selezionare un prodotto!"); 	
    }

    @FXML
    void doGeneraMRP(ActionEvent event) {
    	Result.clear();
    	String selezionato = listaProdottiFiniti.getValue();
    	if(selezionato!=null)
    	    Result.setText(model.generaMRP(selezionato));
    	else
    		Result.setText("Selezionare un prodotto per l'MRP!"); 
    		
    }

    @FXML
    void doInserisciProdotto(ActionEvent event) {
    	
    	Result.clear();
    	float domandaMensile;
        int leadTime;
    	float lotSize;
    	float valore;
    	
    	
    	String prodottoID=codiceTetx.getText();    	
    	if(prodottoID.length()==0){
    		Result.setText("Inserire il codice prodotto");
    		return;
    	}
    		
    	String descrizione=DescrizioneText.getText();
    	if(descrizione.length()==0){
    		Result.setText("Inserire la descrizione del prodotto");
    		return;
    	}
    	
    	String lot= LotsizeText.getText();
    	if(lot.length()==0){
    		Result.setText("Inserire la dimensione di lotto del prodotto");
    		return;
    	}
    	else{
    		try{
    			lotSize= Float.parseFloat(lot);
    		}
    		catch (NumberFormatException e) {
    			Result.appendText("Formato numerico errato nella dimensione del lotto\n") ;
    			return ;
    	  }
    	}
    		
    	String time = LeadTimeText.getText();
    	if(time.length()==0){
    		Result.setText("Inserire il lead time del prodotto");
    		return;
    	}
    	else{
    		try{
    			leadTime= Integer.parseInt(time);
    		}
    		catch (NumberFormatException e) {
    			Result.appendText("Formato numerico errato nel lead time\n") ;
    			return ;
    	  }
    	}
    		
    	
    	String domanda = DomandaTxt.getText();
    	if(domanda.length()==0){
    		Result.setText("Inserire la domanda del prodotto");
    		return;
    	}
    	else{
    		try{
    			domandaMensile= Float.parseFloat(domanda);
    		}
    		catch (NumberFormatException e) {
    			Result.appendText("Formato numerico errato nella domanda\n") ;
    			return ;
    	  }
    	}
    		
    	
    	
    	
    	String val = ValoreTxt.getText() ;
    	if(val.length()==0){
    		Result.setText("Inserire il valore monetario del prodotto");
    		return;
    	}
    	else{
    		try{
    			valore= Float.parseFloat(val);
    		}
    		catch (NumberFormatException e) {
    			Result.appendText("Formato numerico errato nel valore monetario\n") ;
    			return ; 
    	  }

    	}
       if(model.inserisciNuovoProdotto(prodottoID, descrizione, domandaMensile, leadTime, lotSize, valore)){    	
    	Result.setText("Prodotto aggiunto!");
    	updateView();}
       else
    	   Result.setText("Il prodotto � gi� presente");
    }

    
    
    @FXML
    void initialize() {
        assert ChildTxt != null : "fx:id=\"ChildTxt\" was not injected: check your FXML file 'mrp.fxml'.";
        assert Controller != null : "fx:id=\"Controller\" was not injected: check your FXML file 'mrp.fxml'.";
        assert DescrizioneText != null : "fx:id=\"DescrizioneText\" was not injected: check your FXML file 'mrp.fxml'.";
        assert DomandaTxt != null : "fx:id=\"DomandaTxt\" was not injected: check your FXML file 'mrp.fxml'.";
        assert LeadTimeText != null : "fx:id=\"LeadTimeText\" was not injected: check your FXML file 'mrp.fxml'.";
        assert LotsizeText != null : "fx:id=\"LotsizeText\" was not injected: check your FXML file 'mrp.fxml'.";
        assert ParentText != null : "fx:id=\"ParentText\" was not injected: check your FXML file 'mrp.fxml'.";
        assert QuantitaText != null : "fx:id=\"QuantitaText\" was not injected: check your FXML file 'mrp.fxml'.";
        assert Result != null : "fx:id=\"Result\" was not injected: check your FXML file 'mrp.fxml'.";
        assert ValoreTxt != null : "fx:id=\"ValoreTxt\" was not injected: check your FXML file 'mrp.fxml'.";
        assert aggiungiButton != null : "fx:id=\"aggiungiButton\" was not injected: check your FXML file 'mrp.fxml'.";
        assert cercaButton != null : "fx:id=\"cercaButton\" was not injected: check your FXML file 'mrp.fxml'.";
        assert codiceTetx != null : "fx:id=\"codiceTetx\" was not injected: check your FXML file 'mrp.fxml'.";
        assert generaMRPButton != null : "fx:id=\"generaMRPButton\" was not injected: check your FXML file 'mrp.fxml'.";
        assert inserisciButton != null : "fx:id=\"inserisciButton\" was not injected: check your FXML file 'mrp.fxml'.";
        assert listaProdotti != null : "fx:id=\"listaProdotti\" was not injected: check your FXML file 'mrp.fxml'.";
        assert listaProdottiFiniti != null : "fx:id=\"listaProdottiFiniti\" was not injected: check your FXML file 'mrp.fxml'.";

        
        setModel(new Model());
        ObservableList<String> prodotti_lista = FXCollections.observableList(new ArrayList<String>());
        for(String s : model.getListaProdotti().keySet() )
        	prodotti_lista.add(s);
        listaProdotti.setItems(prodotti_lista);
        
        ObservableList<String> prodottiFiniti_lista = FXCollections.observableList(new ArrayList<String>());
        for(String s : model.getListaProdottiFiniti() )
        	prodottiFiniti_lista.add(s);
        listaProdottiFiniti.setItems(prodottiFiniti_lista);

    }
    
    public Model getModel() {
		return model;
	}

	public void setModel(Model model) {
		this.model = model;
	}
	
	public void updateView(){
		ObservableList<String> prodotti_lista = FXCollections.observableList(new ArrayList<String>());
		 for(String s : model.getListaProdotti().keySet() )
	        	prodotti_lista.add(s);
	        listaProdotti.setItems(prodotti_lista);
	        
	        ObservableList<String> prodottiFiniti_lista = FXCollections.observableList(new ArrayList<String>());
	        for(String s : model.getListaProdottiFiniti() )
	        	prodottiFiniti_lista.add(s);
	        listaProdottiFiniti.setItems(prodottiFiniti_lista);
	        
	        DescrizioneText.clear();
	        DomandaTxt.clear();
	        LeadTimeText.clear();
	        LotsizeText.clear();
	        QuantitaText.clear();	       
	        ValoreTxt.clear();    
	        codiceTetx.clear();


	       
	        
	        
	}

}
