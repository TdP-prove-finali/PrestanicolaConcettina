----Istruzioni per l'installazione----

Scaricare ed installare la piattaforma di sviluppo Java Platform(JDK) 7. 
NON � necessario scaricare ed installare JavaFX, in quanto tale pacchetto  � gi� incluso in Java .

Il tool utilizzato per lo sviluppo � Eclipse  nella versione IDE for Java Developers  a cui � stato installato il pacchetto e(fx)eclispe utile per sviluppare JavaFX. 
Sscaricato il download di Eclipse,estrarre la cartella dall�archivio e lanciare l�ambiente di sviluppo. Dalla barra del men�, selezionare Help -> Eclipse Marketplace,cercare �javafx� ed installare il pacchetto e(fx)clipse.

Per la connessione al database � necessario  mysql-connector-java-5.1.23-bin.jar.  Occorre quindi Database MySQL "Community Edition", scaricabile da https://dev.mysql.com/.
Per Windows, esiste un comodo "MySQL Installer" in grado di installare e configurare i componenti necessari. Per gli altri sistemi operativi, i componenti necessari sono: MySQL Community Server, MySQL Workbench,MySQL Connector/J. Un tool molto pi� leggero del Workbench, per interfacciarsi con il database MySQL, � HeidiSQL (solo Windows).

Installare la libreria Libreria JGraphT  usata per la manipolazione dei grafi.

Importare il progetto Tesi in Eclipse:  File-->Import . Nella finestra di dialogo selezionare  �Existing projects into Workspace� e quindi cliccare su �Next�.Selezionare �Select archive file� e scegliere il file di archivio contenente il progetto da importare.


--Istruzioni per testare l'applicazione----
Aprire il package tesi.db e inserire le proprie credenziali per la connessione al database: user e password. 
� ora possibile lanciare l'applicazione cliccando sulla voce Run.


----Informazioni sul dataset----

Il database utilizzato � prodottidb ed � stato fornito dal docente Paolo Chiabert.
Esso si trova all'interno della cartella data del progetto.
� permesso il suo riuso.

----Licenza d'uso----

Copyright 2014 Concettina Prestanicola
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
    http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
